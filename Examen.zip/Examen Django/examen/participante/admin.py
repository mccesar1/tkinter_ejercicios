from django.contrib import admin

from .models import Participante

admin.site.register(Participante)